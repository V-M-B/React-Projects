import React from 'react'

export default function Favorites() {
    

    return (
<div className="">fav</div>
    )
}

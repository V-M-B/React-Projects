import React from 'react'

export default function SingleGif() {
    

    return (
<div className="">
    single
</div>
    )
}
